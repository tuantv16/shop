<script>
import { ErrorMessage, Field } from "vee-validate";
import "vue-select/dist/vue-select.css";
import vSelect from "vue-select";

export default {
  components: {
    Field,
    ErrorMessage,
    vSelect,
  },
  data() {
    return {
      input_search: "",
    };
  },
  props: {
    options: {
      type: Array,
      default: [],
    },
    name: {
      type: String,
      default: "",
    },
    label: {
      type: String,
      default: "",
    },
    data: {
      type: [String, Number],
      default: "",
    },
    title: {
      type: String,
      default: "",
    },
  },
  emits: ["change"],
  watch: {
    input_search: function (val) {
      this.$emit("change", val);
    },
    // data: function (val) {
    //   // dùng cho màn hình edit
    //   this.input_search = val;
    // },
  },
  created() {

    this.input_search = this.data;

  },
  methods: {
    // handleSelectChange(value) {
    //   console.log(value);
    //   this.$emit("change", value);
    // },

  },
};
</script>

<template>
 <div class="form-group row">
    <label class="col-sm-3 col-form-label text-md-right" >
        {{ title }}
        <i v-if="tooltip" class="far fa-question-circle"></i>
        <span class="required ml-1" v-if="required">必須</span>
    </label>
    <div class="col-sm-9">

        <Field v-slot="{ field, errors }" :name="name">
            <v-select
            :options="options"
            v-model="input_search"
            :clearable="false"
            class="v-select-custom"
            :class="errors.length > 0 ? 'is-invalid-select' : ''"

            >
            <template v-slot:no-options>データがありません</template>
            </v-select>
        </Field>
        <ErrorMessage :name="name" />
    </div>
</div>

</template>

<style scoped>
</style>
