<script>
import {Form, Field, ErrorMessage} from "vee-validate";
import {ProductAddValidator} from "../validate.add.js";
import * as yup from "yup";
import {ProductService} from "../product.service.js";
import InputCustomComponent from './InputCustomComponent.vue'
import SelectBoxCustomComponent from './SelectBoxCustomComponent.vue'
import {BASE_URL} from "../../../route.js";
import {
    MSG_CONFIRM_SAVE,
    MSG_UPDATE_FAIL
} from "../../../constants/common-messages.js";
import UploadFieldComponent from "./UploadFileProductComponent.vue";
import RadiosComponent from "../../../components/RadiosComponent.vue";
import SingleCheckboxComponent from "../../../components/SingleCheckboxComponent.vue";
import "vue-select/dist/vue-select.css";
import vSelect from 'vue-select'
import SelectBox2Component from "../../../components/SelectBox2Component.vue";

export default {
    components: {
        SingleCheckboxComponent,
        RadiosComponent,
        UploadFieldComponent,
        Form,
        Field,
        ErrorMessage,
        InputCustomComponent,
        SelectBoxCustomComponent,
        SelectBox2Component,
        vSelect
    },
    data() {
        return {
            initData: {
                makerIdSelected: '',
                kbnSelected: '',
                bagSelected: '',
                soutiSelected: '',
                spQualitySelected: '',
                customerSelected: '',
                new_path_text: '',
                save_yaer: '5',
                pack_cnt: '100',
                dsp_no: '999',
                new_path: '',
                bousabi: 0,
                hasuu: 0,
            },
            redirect: '',
            listKbns: {}
        }
    },
    created() {
        let params = new URL(location.href).searchParams;
        if(!!params.get('redirect')) {
            this.redirect = '?'+decodeURIComponent(params.get('redirect'));
        }
        this.listKbns = JSON.stringify(this.listKbns);
        this.initData = this.products?.id ? this.products : this.initData;
        this.initData.makerIdSelected = this.products.maker_id;
        this.initData.bousabi = Number(this.products.bousabi);
        this.initData.hasuu = Number(this.products.hasuu);
        this.new_path_text = this.initData.new_path;
        delete this.initData.new_path;
        if (this.copy === 1) {
            delete this.initData.id;
            this.new_path_text = '';
        }
    },
    computed: {
        schema() {
            let rules = ProductAddValidator(this);
            return yup.object().shape(rules);
        },
        BASE_URL() {
            return BASE_URL;
        }
    },
    methods: {
        onSubmit(values) {
            values.bousabi = values?.bousabi ? parseInt(values.bousabi) : 0;
            values.hasuu = values?.hasuu ? parseInt(values.hasuu) :  0;

            console.log(values);
            debugger;
            if (this.initData.id) {
                this.confirm(MSG_CONFIRM_SAVE, () => {
                    ProductService.saveData(values).then((res) => {
                        if (res.data.status === 'success') {
                            window.location.href = BASE_URL + `admin/products`;
                        } else {
                            this.msgAlert(MSG_UPDATE_FAIL);
                        }
                    }).catch((err) => {
                        this.msgAlert(err.response.data.message);
                    });
                });
            } else {
                ProductService.saveData(values).then((res) => {
                    if (res.data.status === 'success') {
                        //window.location.href = BASE_URL + `admin/accuracies`;
                        window.location.href = BASE_URL + 'admin/accuracies/standard/' + values.product + '/'+ values.maker_id+'/lotno/accuracy';
                    } else {
                        this.msgAlert(MSG_UPDATE_FAIL);
                    }

                }).catch((err) => {
                    this.msgAlert(err.response.data.message);
                })
            }
        },
        getCustomers() {
            return  this.customers.map(row => {
                return { value: row.maker_id, label: row.maker_name }
            });
        },
        selectedCustomer(makerId) {
            let obj = {};
            let rowData = this.customers.find(row => row.maker_id == makerId);
            obj.value = rowData.maker_id;
            obj.label = rowData.maker_name;
            return obj;
        }

    },
    props: {
        list_kbns: {
            type: Object,
            default: {}
        },
        sp_qualities: {
            type: Object,
            default: {}
        },
        bags: {
            type: Object,
            default: {}
        },
        soutis: {
            type: Object,
            default: {}
        },
        customers: {
            type: Object,
            default: {}
        },
        products: {
            type: Object,
            default: {}
        },
        copy: {
            type: Number,
            default: 0
        },
    },
    mounted() {

    }
}
</script>

<template>
    <Form :initial-values="initData" v-slot="{setFieldValue, errors, values}" @submit="onSubmit" @invalid-submit="onInvalid"
          :validation-schema="schema">
        <button type="submit" id="createProduct" class="d-none">Submit</button>
        <div class="col-12 col-md-8">
            <!-- <select-box-component :data="initData.maker_id ?? initData.makerIdSelected" title="客先" id="maker_id"
                                  name="maker_id" :required="true">
                <option value=""></option>
                <option v-for="(items, key) in this.customers" :key="key" :value="items.maker_id"> {{
                        items.maker_name
                    }}
                </option>
            </select-box-component> -->
            <select-box-2-component
                title="客先"
                :options="getCustomers()"
                name="maker_id"
                :data="initData.maker_id ? selectedCustomer(initData.maker_id) : ''"
                @change="(val) => {
                    console.log('val', val);
                    setFieldValue('maker_id', val.value);
                }"
            />

        </div>

        <div class="col-12 col-md-8">
            <input-component title="品番" :required="true" :data="initData.product" limit="80" id="product"
                             name="product"/>
        </div>

        <div class="col-12 col-md-8">
            <input-component title="品名" :data="initData.product_name" id="product_name" limit="80"
                             name="product_name"/>
        </div>

        <div class="col-12 col-md-8">
            <div class="row">
                <label class="col-md-3 col-form-label text-md-right" data-toggle="tooltip" title="">梱包数</label>
                <div class="col-md-9">
                    <div class="form-group row">
                        <input-custom-component title="受入" :data="initData.pack_cnt" :limit="11" id="pack_cnt"
                                                name="pack_cnt"/>
                        <input-custom-component title="出荷" :data="initData.pack_cnt2" :limit="30" id="pack_cnt2"
                                                name="pack_cnt2"/>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-8">
            <upload-field-component
                :currentFieldNameProp="new_path_text"
                accept=".xls,.xlsx" title="パスポート" :data="initData.new_path" limit="512"
                                    id="new_path" name="new_path"/>
        </div>

        <div class="col-12 col-md-8">
            <input-component title="表示順" :data="initData.dsp_no" :limit="3" id="dsp_no" name="dsp_no"/>
        </div>

        <div class="col-12 col-md-8">
            <select-box-component :data="initData.kbn ?? initData.kbnSelected" limit="20" title="区分" id="kbn"
                                  name="kbn">
                <option value=""></option>
                <option v-for="(value, key) in this.list_kbns" :key="key" :value="key"> {{ value }}</option>
            </select-box-component>
        </div>

        <div class="col-12 col-md-8">
            <input-component :required="true" title="保管期間" :limit="11" :data="initData.save_yaer" id="save_yaer"
                             name="save_yaer"/>
        </div>

        <div class="col-12 col-md-8">
            <input-component title="QC番号" :data="initData.qc_code" limit="16" id="qc_code" name="qc_code"/>
        </div>

        <div class="col-12 col-md-8">
            <select-box-component :data="initData.bag ?? initData.bagSelected" title="袋" id="bag" name="bag">
                <option value=""></option>
                <option v-for="(value, key) in this.bags" :key="key" :value="value"> {{ value }}</option>
            </select-box-component>
        </div>

        <!-- test -->
        <div class="col-12 col-md-8">
            <div class="row">
                <label class="col-md-3 col-form-label text-md-right" data-toggle="tooltip" title="">設備</label>
                <div class="col-md-9">
                    <div class="form-group row container" style="padding:0">
                        <div class="col-sm-4">
                            <!-- <select-box-custom-component :data="initData.mcno1" id="mcno1" name="mcno1">
                                <option value=""></option>
                                <option v-for="(value, key) in this.soutis" :key="key" :value="value"> {{
                                        value
                                    }}
                                </option>
                            </select-box-custom-component> -->

                           <select-box-2-component
                                title="客先"
                                :options="Object.values(this.soutis)"
                                name="mcno1"
                                :data="initData.mcno1"
                                @change="(val) => {
                                    console.log('val', val);
                                    setFieldValue('mcno1', val);
                                }"
                            />

                        </div>
                        <div class="col-sm-4">
                            <select-box-custom-component :data="initData.mcno2" id="mcno2" name="mcno2">
                                <option value=""></option>
                                <option v-for="(value, key) in this.soutis" :key="key" :value="value"> {{
                                        value
                                    }}
                                </option>
                            </select-box-custom-component>
                        </div>
                        <div class="col-sm-4">
                            <select-box-custom-component :data="initData.mcno3" id="mcno3" name="mcno3">
                                <option value=""></option>
                                <option v-for="(value, key) in this.soutis" :key="key" :value="value"> {{
                                        value
                                    }}
                                </option>
                            </select-box-custom-component>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-8">
            <input-component title="単価" :data="initData.price" limit="10" id="price" name="price"/>
        </div>

        <div class="col-12 col-md-8">
            <input-component title="材質" :data="initData.material" limit="60" id="material" name="material"/>
        </div>

        <div class="col-12 col-md-8">
            <select-box-component :data="initData.sp_quality ?? initData.spQualitySelected" title="特殊特製"
                                  id="sp_quality" name="sp_quality">
                <option value=""></option>
                <option v-for="(value, key) in this.sp_qualities" :key="key" :value="key"> {{ value }}</option>
            </select-box-component>
        </div>
        <div class="col-12 col-md-8">
            <div class="row" >
                <label class="col-sm-3 col-form-label text-md-right" >
                </label>
                <div class="wrapper col-sm-9" >
                    <div class="row" >
                        <div class="col-sm-5" >
                            <single-checkbox-component
                                input-cols="col-sm-6"
                                label-cols="col-sm-6"
                                title="防錆"
                                :data="initData.bousabi" name="bousabi" />
                        </div>
                        <div class="col-sm-7" >
                            <single-checkbox-component
                                input-cols="col-sm-6"
                                label-cols="col-sm-6"
                                title="端数出荷"
                                :data="initData.hasuu" name="hasuu" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-8">
            <div class="form-group row">
                <label class="col-sm-3 col-form-label text-md-right" data-toggle="tooltip" title="">注意事項</label>
                <div class="col-sm-9">
                    <input-component :data="initData.caution1" id="caution1" name="caution1"/>
                    <input-component :data="initData.caution2" id="caution2" name="caution2"/>
                    <input-component :data="initData.caution3" id="caution3" name="caution3"/>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-8">
            <div class="form-group row">
                <label class="col-sm-3"></label>
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-md-6 text-md-right">
                            <a class="btn btn-danger mr-4" :href="BASE_URL + 'admin/products'+redirect">戻る</a>
                        </div>
                        <div class="col-md-6 text-md-left">
                            <button class="btn btn-primary" >保存</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </Form>
</template>

